package com.wjh.static_ex;

public class MainClass {

	public static void main(String[] args) {

		PrintClass pc = new PrintClass();
		DataClass dc = new DataClass();
		
		pc.printPrice();
		System.out.println("\n");
		
		dc.martsumEA();
		dc.sumEA();
		
		}
}
