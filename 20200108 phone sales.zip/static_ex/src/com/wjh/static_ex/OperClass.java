package com.wjh.static_ex;

public class OperClass {
	
	
	public OperClass(){
		
	}
	
	static void sum() {
	
	}
}
